import{e as t}from"./request.a43d7f63.js";const l=()=>t({url:"/api/install/status",method:"get"}),e=s=>t({url:"/api/install",method:"post",data:s});export{e as a,l as i};
