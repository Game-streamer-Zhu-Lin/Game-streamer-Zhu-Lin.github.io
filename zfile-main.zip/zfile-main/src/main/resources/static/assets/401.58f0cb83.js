var e="/assets/401.f56d4c2a.svg",_=Object.freeze(Object.defineProperty({__proto__:null,default:e},Symbol.toStringTag,{value:"Module"}));export{e as _,_ as a};
