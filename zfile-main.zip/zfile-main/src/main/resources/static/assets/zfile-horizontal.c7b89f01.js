var e="/assets/zfile-horizontal.abd5aec9.svg",a=Object.freeze(Object.defineProperty({__proto__:null,default:e},Symbol.toStringTag,{value:"Module"}));export{a as _,e as a};
