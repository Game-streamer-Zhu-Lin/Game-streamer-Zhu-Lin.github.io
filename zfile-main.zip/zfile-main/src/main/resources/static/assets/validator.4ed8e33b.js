import{ah as i}from"./base.5bbd9596.js";const n=o=>["",...i].includes(o);export{n as i};
