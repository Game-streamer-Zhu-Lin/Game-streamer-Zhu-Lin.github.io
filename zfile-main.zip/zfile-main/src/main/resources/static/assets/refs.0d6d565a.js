import{l as t}from"./index.13a41ddb.js";const e=(...c)=>s=>{c.forEach(o=>{t(o)?o(s):o.value=s})};export{e as c};
