import{v as o,L as a}from"./directive.dac6fe0e.js";const n={install(i){i.directive("loading",o),i.config.globalProperties.$loading=a},directive:o,service:a};export{n as E};
