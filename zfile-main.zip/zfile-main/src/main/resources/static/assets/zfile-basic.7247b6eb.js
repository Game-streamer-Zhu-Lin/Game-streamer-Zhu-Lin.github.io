var e="/assets/zfile-basic.58891cac.svg",a=Object.freeze(Object.defineProperty({__proto__:null,default:e},Symbol.toStringTag,{value:"Module"}));export{e as _,a};
