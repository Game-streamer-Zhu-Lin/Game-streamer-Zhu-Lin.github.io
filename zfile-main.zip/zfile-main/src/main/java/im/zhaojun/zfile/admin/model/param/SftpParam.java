package im.zhaojun.zfile.admin.model.param;

import lombok.Getter;

/**
 * SFTP 初始化参数
 *
 * @author zhaojun
 */
@Getter
public class SftpParam extends FtpParam {

}