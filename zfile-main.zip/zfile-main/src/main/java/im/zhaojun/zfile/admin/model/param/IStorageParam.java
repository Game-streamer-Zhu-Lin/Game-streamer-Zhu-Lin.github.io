package im.zhaojun.zfile.admin.model.param;


public interface IStorageParam {
}