package im.zhaojun.zfile.admin.model.param;

import lombok.Getter;

/**
 * 华为云初始化参数
 *
 * @author zhaojun
 */
@Getter
public class HuaweiParam extends S3BaseParam {

}