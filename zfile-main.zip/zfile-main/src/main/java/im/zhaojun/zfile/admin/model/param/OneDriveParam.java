package im.zhaojun.zfile.admin.model.param;

import lombok.Getter;

/**
 * OneDrive 初始化参数
 *
 * @author zhaojun
 */
@Getter
public class OneDriveParam extends MicrosoftDriveParam {

}