package im.zhaojun.zfile.admin.model.param;

/**
 * 代理上传参数
 *
 * @author zhaojun
 */
public class ProxyUploadParam extends ProxyTransferParam {

}