package im.zhaojun.zfile.common.exception;

/**
 * 禁止服务器代理下载异常
 *
 * @author zhaojun
 */
public class DisableProxyDownloadException extends RuntimeException {

}