package im.zhaojun.zfile.admin.model.param;

import lombok.Getter;

/**
 * 代理下载参数
 *
 * @author zhaojun
 */
@Getter
public class ProxyDownloadParam extends ProxyTransferParam {

}