package im.zhaojun.zfile.admin.model.param;

import lombok.Getter;

/**
 * 七牛云初始化参数
 *
 * @author zhaojun
 */
@Getter
public class QiniuParam extends S3BaseParam {

}