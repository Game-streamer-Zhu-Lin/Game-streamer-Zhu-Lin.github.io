package im.zhaojun.zfile.admin.model.param;

import lombok.Getter;

/**
 * 阿里云初始化参数
 *
 * @author zhaojun
 */
@Getter
public class AliyunParam extends S3BaseParam {

}