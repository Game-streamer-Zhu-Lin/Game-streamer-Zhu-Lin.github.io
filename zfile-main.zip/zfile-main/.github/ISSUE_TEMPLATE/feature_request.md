---
name: 功能建议
about: 想让我们为 ZFile 增加什么功能吗？
title: 'feat: '
labels: 'Feature Request'
assignees: ''

---


为了帮助我们更好的解决您的问题，请填写以下选项（不填写完整可能会被直接关闭 issue）：

- 是否已搜索其他 issue，没有人提过这个功能？：
- 是否已尝试使用最新版本，且仍然没有此功能？：
- 功能概述：
- 功能动机：
- 详细解释（可选）：